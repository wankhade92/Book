from django.apps import AppConfig


class BookRecordsConfig(AppConfig):
    name = 'book_records'
