from django.shortcuts import render
from rest_framework.response import Response
from rest_framework.decorators import api_view

# Create your views here.
@api_view(['GET'])
def bookOverview(request):
    book_records_urls={
        'List':'/product_list/',
        'Create':'/product_create/',
        'Update':'/product_update/<int:id>'
    }

    return Response(book_records_urls)