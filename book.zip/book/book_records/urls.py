from django.urls import path
from . import views

urlpatterns=[
    path('',views.bookOverview,name='bookOverview'),
] 